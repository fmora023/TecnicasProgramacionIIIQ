﻿namespace DBExample.Model
{
    /// <summary>
    /// Model for CatalogTypes table.
    /// </summary>
    public class CatalogTypes
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>
        /// The type.
        /// </value>
        public string? Type { get; set; }
    }
}
